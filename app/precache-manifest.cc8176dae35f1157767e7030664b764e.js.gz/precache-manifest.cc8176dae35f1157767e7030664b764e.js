self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "565655c81a231f7e7de576bf340e4ded",
    "url": "/index.html"
  },
  {
    "revision": "fa57d1928447f710619ce65212c033dc",
    "url": "/public/images/group.jpeg"
  },
  {
    "revision": "f21f3d0be8db3cc07aa0cde0f180f698",
    "url": "/public/images/h6.jpeg"
  },
  {
    "revision": "4f2f51369a105ff47da1b0916156f439",
    "url": "/public/images/happy.jpeg"
  },
  {
    "revision": "efe587a509582fcd7a096f8adf352ce2",
    "url": "/public/images/smile.jpeg"
  },
  {
    "revision": "cc4262a553ca40283ddb87cf0b6d39d0",
    "url": "/public/images/triv.png"
  },
  {
    "revision": "daf98962f3b9955b6c21e1359c5588a1",
    "url": "/public/images/u.jpeg"
  },
  {
    "revision": "5fdc191bc1f7c1a6bb352125b18373be",
    "url": "/public/images/y.jpeg"
  },
  {
    "url": "/public/javascript/app.fbaae15d9229ded81e05.js"
  },
  {
    "revision": "fbaae15d9229ded81e05",
    "url": "/public/styles/app.css"
  }
]);